package com.example.anydubclone.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.example.anydubclone.MainActivity
import com.example.anydubclone.util.VoskHelper
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Servicio de captura de audio del sistema + reconocimiento Vosk.
 */
class TranslationService : Service() {

    companion object {
        const val CHANNEL_ID = "anydub_translation_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.anydubclone.START_CAPTURE"
        const val ACTION_STOP = "com.example.anydubclone.STOP_CAPTURE"

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_MODE = "mode"
        const val EXTRA_MODEL = "model"

        const val BROADCAST_AUDIO_LEVEL = "com.example.anydubclone.AUDIO_LEVEL"
        const val BROADCAST_STT_RESULT = "com.example.anydubclone.STT_RESULT"
        const val BROADCAST_STATUS = "com.example.anydubclone.STATUS"

        const val EXTRA_LEVEL = "level"
        const val EXTRA_IS_SPEECH = "is_speech"
        const val EXTRA_TEXT = "text"
        const val EXTRA_IS_FINAL = "is_final"
        const val EXTRA_STATUS = "status"

        private const val TAG = "TranslationService"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureThread: Thread? = null
    private var voskHelper: VoskHelper? = null
    private val isCapturing = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                val modelKey = intent.getStringExtra(EXTRA_MODEL) ?: "en"

                startForeground(NOTIFICATION_ID, buildNotification("Iniciando Vosk…"))

                Thread {
                    voskHelper = VoskHelper(
                        context = this,
                        onPartial = { text -> broadcastStt(text, isFinal = false) },
                        onFinal = { text -> broadcastStt(text, isFinal = true) },
                        onStatus = { status ->
                            broadcastStatus(status)
                            updateNotification(status)
                        },
                        onError = { err ->
                            broadcastStatus(err)
                            Log.e(TAG, err)
                        }
                    )
                    val modelName = if (modelKey == "es") VoskHelper.MODEL_ES else VoskHelper.MODEL_EN
                    voskHelper?.init(modelName)

                    if (resultCode == Activity.RESULT_OK && resultData != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            mainHandler.post {
                                startSystemAudioCapture(resultCode, resultData)
                            }
                        } else {
                            broadcastStatus("Se requiere Android 10+")
                            stopSelf()
                        }
                    } else {
                        broadcastStatus("MediaProjection no concedido")
                        stopSelf()
                    }
                }.start()
            }
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification("Traducción en vivo activa"))
            }
        }
        return START_STICKY
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun startSystemAudioCapture(resultCode: Int, resultData: Intent) {
        if (isCapturing.get()) return

        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)

        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                Log.i(TAG, "MediaProjection detenida")
                stopCapture()
                stopSelf()
            }
        }, mainHandler)

        val config = AudioPlaybackCaptureConfiguration.Builder(mediaProjection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val minBufSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        val bufferSize = minBufSize * 2

        try {
            audioRecord = AudioRecord.Builder()
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AUDIO_FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_CONFIG)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setAudioPlaybackCaptureConfig(config)
                .build()

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord no inicializado")
                stopCapture()
                stopSelf()
                return
            }

            audioRecord?.startRecording()
            isCapturing.set(true)
            startCaptureLoop(bufferSize)
            updateNotification("Capturando + Vosk activo")
            broadcastStatus("Capturando audio del sistema…")
            Log.i(TAG, "Captura + Vosk iniciados")
        } catch (e: Exception) {
            Log.e(TAG, "Error al iniciar captura", e)
            broadcastStatus("Error captura: ${e.message}")
            stopCapture()
            stopSelf()
        }
    }

    private fun startCaptureLoop(bufferSize: Int) {
        captureThread = Thread {
            val shortBuffer = ShortArray(bufferSize / 2)
            var consecutiveSpeechFrames = 0

            while (isCapturing.get()) {
                val read = audioRecord?.read(shortBuffer, 0, shortBuffer.size) ?: -1
                if (read > 0) {
                    val level = calculateRms(shortBuffer, read)
                    val isSpeech = level > 0.015f
                    if (isSpeech) consecutiveSpeechFrames++ else consecutiveSpeechFrames = 0

                    sendBroadcast(Intent(BROADCAST_AUDIO_LEVEL).apply {
                        setPackage(packageName)
                        putExtra(EXTRA_LEVEL, level)
                        putExtra(EXTRA_IS_SPEECH, isSpeech && consecutiveSpeechFrames > 2)
                    })

                    voskHelper?.acceptWaveform(shortBuffer, read)
                } else if (read < 0) {
                    Log.w(TAG, "AudioRecord read error: $read")
                    break
                }
            }
        }.also {
            it.name = "SystemAudioCapture+Vosk"
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    private fun calculateRms(buffer: ShortArray, size: Int): Float {
        var sum = 0.0
        for (i in 0 until size) {
            val sample = buffer[i].toDouble()
            sum += sample * sample
        }
        val rms = Math.sqrt(sum / size)
        return (rms / 8000.0).coerceIn(0.0, 1.0).toFloat()
    }

    private fun broadcastStt(text: String, isFinal: Boolean) {
        sendBroadcast(Intent(BROADCAST_STT_RESULT).apply {
            setPackage(packageName)
            putExtra(EXTRA_TEXT, text)
            putExtra(EXTRA_IS_FINAL, isFinal)
        })
    }

    private fun broadcastStatus(status: String) {
        sendBroadcast(Intent(BROADCAST_STATUS).apply {
            setPackage(packageName)
            putExtra(EXTRA_STATUS, status)
        })
    }

    private fun stopCapture() {
        isCapturing.set(false)
        try { captureThread?.join(800) } catch (_: InterruptedException) {}
        captureThread = null

        voskHelper?.flush()
        voskHelper?.close()
        voskHelper = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null

        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null

        Log.i(TAG, "Captura y Vosk detenidos")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Captura + Vosk",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Captura de audio del sistema y reconocimiento Vosk"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, TranslationService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AnyDub Clone")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .addAction(android.R.drawable.ic_media_pause, "Detener", stopPending)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopCapture()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
