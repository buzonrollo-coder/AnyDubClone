package com.example.anydubclone.util

import android.content.Context
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Helper de traducción inspirado en AnyDub.
 *
 * AnyDub permite elegir entre Microsoft, Google o su motor propio.
 * Aquí usamos ML Kit (Google) on-device cuando es posible.
 *
 * Nota: ML Kit requiere descargar el modelo de idioma la primera vez.
 * Para máxima cobertura de idiomas se puede complementar con una API
 * (Google Cloud Translation, DeepL, Microsoft Translator, etc.).
 */
class TranslatorHelper(private val context: Context) {

    private var translator: Translator? = null
    private var isModelReady = false

    init {
        // Por defecto: de inglés a español (el caso más común).
        // En una versión más completa se detectaría el idioma fuente.
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.SPANISH)
            .build()
        translator = Translation.getClient(options)
        downloadModelIfNeeded()
    }

    private fun downloadModelIfNeeded() {
        val conditions = DownloadConditions.Builder()
            .requireWifi() // o quitar para permitir datos móviles
            .build()
        translator?.downloadModelIfNeeded(conditions)
            ?.addOnSuccessListener {
                isModelReady = true
            }
            ?.addOnFailureListener {
                // Fallback: se usará traducción online o se devolverá el original
                isModelReady = false
            }
    }

    /**
     * Traduce texto a español.
     * Si el modelo aún no está listo o falla, se puede usar un fallback simple.
     */
    suspend fun translateToSpanish(text: String): String {
        if (text.isBlank()) return text

        val client = translator ?: return text

        return suspendCancellableCoroutine { cont ->
            client.translate(text)
                .addOnSuccessListener { translated ->
                    cont.resume(translated)
                }
                .addOnFailureListener { e ->
                    // Fallback muy simple: devolver original + aviso
                    // En producción aquí se llamaría a una API de traducción online
                    cont.resume("[$text]") // o cont.resumeWithException(e)
                }
        }
    }

    /**
     * Cambia el par de idiomas (útil si se detecta el idioma fuente).
     */
    fun setLanguagePair(source: String, target: String = TranslateLanguage.SPANISH) {
        translator?.close()
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(source)
            .setTargetLanguage(target)
            .build()
        translator = Translation.getClient(options)
        isModelReady = false
        downloadModelIfNeeded()
    }

    fun close() {
        translator?.close()
        translator = null
    }
}
