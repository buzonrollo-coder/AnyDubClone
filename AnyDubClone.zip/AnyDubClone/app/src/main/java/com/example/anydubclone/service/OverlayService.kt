package com.example.anydubclone.service

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import com.example.anydubclone.R

/**
 * Overlay flotante estilo AnyDub para mostrar subtítulos originales + traducidos
 * sobre cualquier app (incluyendo el reproductor de video a pantalla completa).
 *
 * Requiere permiso SYSTEM_ALERT_WINDOW.
 */
class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: android.view.View? = null
    private var tvOriginal: TextView? = null
    private var tvTranslated: TextView? = null

    companion object {
        @Volatile
        private var instance: OverlayService? = null

        fun updateText(original: String?, translated: String?) {
            instance?.updateOverlay(original, translated)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        showOverlay()
    }

    private fun showOverlay() {
        if (overlayView != null) return

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_subtitle, null)

        tvOriginal = overlayView?.findViewById(R.id.tvOverlayOriginal)
        tvTranslated = overlayView?.findViewById(R.id.tvOverlayTranslated)

        overlayView?.findViewById<ImageButton>(R.id.btnOverlayStop)?.setOnClickListener {
            // Enviar broadcast o intent para detener traducción en MainActivity
            stopSelf()
        }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            y = 120 // margen desde abajo
        }

        try {
            windowManager?.addView(overlayView, params)
        } catch (e: Exception) {
            e.printStackTrace()
            // Permiso de overlay no concedido
            stopSelf()
        }
    }

    private fun updateOverlay(original: String?, translated: String?) {
        overlayView?.post {
            tvOriginal?.text = original ?: ""
            tvTranslated?.text = translated ?: original ?: ""
        }
    }

    override fun onDestroy() {
        instance = null
        if (overlayView != null) {
            try {
                windowManager?.removeView(overlayView)
            } catch (_: Exception) {}
            overlayView = null
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
