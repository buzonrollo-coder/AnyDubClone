package com.example.anydubclone.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Gestiona la sincronización del doblaje:
 *
 * 1. **Audio focus con ducking** — al hablar, pide AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
 *    para que YouTube/Netflix bajen el volumen automáticamente.
 * 2. **Cola de frases** — evita cortar frases a medias; encola resultados finales.
 * 3. **Debounce** — espera un poco tras el final de Vosk antes de hablar
 *    (deja que termine el segmento natural).
 * 4. **Velocidad de habla** — ajustable para acercarse al ritmo del original.
 * 5. **Liberación de foco** — al terminar la cola, devuelve el volumen al original.
 */
class DubSyncHelper(
    private val context: Context,
    private val onSpeakingChanged: (Boolean) -> Unit = {},
    private val onQueueSizeChanged: (Int) -> Unit = {}
) {
    companion object {
        private const val TAG = "DubSyncHelper"
        private const val UTTERANCE_PREFIX = "dub_"
        /** Espera tras un resultado final antes de encolar (ms). */
        private const val DEBOUNCE_MS = 180L
        /** Máximo de frases en cola (evita retraso acumulado). */
        private const val MAX_QUEUE = 4
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var tts: TextToSpeech? = null
    private var focusRequest: AudioFocusRequest? = null
    private val queue = ArrayDeque<String>()
    private val isSpeaking = AtomicBoolean(false)
    private val hasFocus = AtomicBoolean(false)

    @Volatile var enabled = true
    @Volatile var speechRate = 1.05f   // ligeramente más rápido = menos retraso
    @Volatile var pitch = 1.0f

    private var utteranceCounter = 0
    private var pendingDebounce: Runnable? = null

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                // Otra app tomó el foco; pausamos nuestra cola
                Log.i(TAG, "Audio focus lost: $change")
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // Nos piden bajar; ya estamos en modo ducking del otro lado
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                // Recuperamos foco
            }
        }
    }

    fun initTts(listener: TextToSpeech.OnInitListener) {
        tts = TextToSpeech(context, listener)
    }

    fun onTtsReady(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts?.apply {
            language = Locale("es", "ES")
            setSpeechRate(speechRate)
            setPitch(pitch)

            setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    isSpeaking.set(true)
                    mainHandler.post { onSpeakingChanged(true) }
                }

                override fun onDone(utteranceId: String?) {
                    mainHandler.post { playNext() }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    mainHandler.post { playNext() }
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    mainHandler.post { playNext() }
                }
            })
        }
    }

    /**
     * Encola una frase traducida para doblar.
     * Aplica debounce y limita el tamaño de la cola.
     */
    fun enqueue(translatedText: String) {
        if (!enabled || translatedText.isBlank()) return

        // Cancelar debounce anterior (varios finales seguidos → solo el último bloque)
        pendingDebounce?.let { mainHandler.removeCallbacks(it) }

        val runnable = Runnable {
            synchronized(queue) {
                // Si la cola está llena, descartamos las más antiguas (priorizar lo actual)
                while (queue.size >= MAX_QUEUE) {
                    queue.removeFirst()
                }
                queue.addLast(translatedText.trim())
                onQueueSizeChanged(queue.size)
            }
            if (!isSpeaking.get()) {
                playNext()
            }
        }
        pendingDebounce = runnable
        mainHandler.postDelayed(runnable, DEBOUNCE_MS)
    }

    private fun playNext() {
        val next: String? = synchronized(queue) {
            if (queue.isEmpty()) null else queue.removeFirst()
        }
        onQueueSizeChanged(synchronized(queue) { queue.size })

        if (next == null) {
            isSpeaking.set(false)
            abandonFocus()
            onSpeakingChanged(false)
            return
        }

        if (!requestFocus()) {
            // Sin foco: igual intentamos hablar
            Log.w(TAG, "No se obtuvo audio focus; hablando igual")
        }

        isSpeaking.set(true)
        onSpeakingChanged(true)

        val id = UTTERANCE_PREFIX + (++utteranceCounter)
        val params = Bundle().apply {
            // STREAM_MUSIC para que el ducking afecte a YouTube etc.
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
        }

        tts?.setSpeechRate(speechRate)
        tts?.setPitch(pitch)

        val result = tts?.speak(next, TextToSpeech.QUEUE_FLUSH, params, id)
        if (result == TextToSpeech.ERROR) {
            Log.e(TAG, "TTS speak error")
            playNext()
        }
    }

    private fun requestFocus(): Boolean {
        if (hasFocus.get()) return true

        val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            // MAY_DUCK: las otras apps (YouTube) bajan el volumen, no se pausan
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(focusChangeListener)
                .setAcceptsDelayedFocusGain(true)
                .setWillPauseWhenDucked(false)
                .build()
            focusRequest = req
            audioManager.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                focusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
        }

        val ok = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        hasFocus.set(ok)
        return ok
    }

    private fun abandonFocus() {
        if (!hasFocus.get()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(focusChangeListener)
            }
        } catch (_: Exception) {}
        hasFocus.set(false)
        focusRequest = null
    }

    /** Cancela cola y TTS; libera foco. */
    fun stop() {
        pendingDebounce?.let { mainHandler.removeCallbacks(it) }
        pendingDebounce = null
        synchronized(queue) { queue.clear() }
        onQueueSizeChanged(0)
        tts?.stop()
        isSpeaking.set(false)
        abandonFocus()
        onSpeakingChanged(false)
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }

    fun isSpeaking(): Boolean = isSpeaking.get()

    fun queueSize(): Int = synchronized(queue) { queue.size }
}
