package com.example.anydubclone.util

import android.content.Context
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.StorageService
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

/**
 * Helper de Vosk para reconocimiento de voz offline a partir de PCM 16 kHz mono.
 *
 * - Descarga el modelo la primera vez (vosk-model-small-en-us-0.15 por defecto).
 * - Acepta buffers ShortArray (PCM 16-bit) del AudioRecord de sistema.
 * - Emite resultados parciales y finales por callback.
 *
 * Modelos recomendados:
 * - Inglés (videos): vosk-model-small-en-us-0.15  (~40 MB)
 * - Español:        vosk-model-small-es-0.42     (~39 MB)
 */
class VoskHelper(
    private val context: Context,
    private val onPartial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onStatus: (String) -> Unit = {},
    private val onError: (String) -> Unit = {}
) {
    companion object {
        private const val TAG = "VoskHelper"

        // Modelo por defecto: inglés (la mayoría de videos de YouTube)
        const val MODEL_EN = "vosk-model-small-en-us-0.15"
        const val MODEL_ES = "vosk-model-small-es-0.42"
        private const val MODEL_BASE_URL = "https://alphacephei.com/vosk/models/"

        private const val SAMPLE_RATE = 16000.0f
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    @Volatile private var isReady = false
    @Volatile private var isClosed = false

    private val modelsDir: File
        get() = File(context.filesDir, "vosk-models").also { it.mkdirs() }

    /**
     * Inicializa Vosk: descarga el modelo si hace falta y crea el Recognizer.
     * Ejecutar en hilo de fondo.
     */
    fun init(modelName: String = MODEL_EN) {
        if (isClosed) return
        try {
            onStatus("Preparando modelo Vosk…")
            val modelPath = ensureModel(modelName)
            if (modelPath == null) {
                onError("No se pudo obtener el modelo Vosk")
                return
            }

            onStatus("Cargando modelo…")
            model = Model(modelPath)
            recognizer = Recognizer(model, SAMPLE_RATE)
            isReady = true
            onStatus("Vosk listo ✓")
            Log.i(TAG, "Modelo cargado: $modelPath")
        } catch (e: Exception) {
            Log.e(TAG, "Error iniciando Vosk", e)
            onError("Error Vosk: ${e.message}")
            isReady = false
        }
    }

    /**
     * Alimenta un buffer PCM 16-bit little-endian (ShortArray del AudioRecord).
     * Debe llamarse desde el hilo de captura.
     */
    fun acceptWaveform(shorts: ShortArray, size: Int) {
        if (!isReady || isClosed) return
        val rec = recognizer ?: return

        // Convertir ShortArray → ByteArray little-endian
        val bytes = ByteArray(size * 2)
        for (i in 0 until size) {
            val s = shorts[i].toInt()
            bytes[i * 2] = (s and 0xFF).toByte()
            bytes[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
        }

        try {
            if (rec.acceptWaveForm(bytes, bytes.size)) {
                // Resultado final de un segmento
                val resultJson = rec.result
                val text = extractText(resultJson)
                if (text.isNotBlank()) {
                    onFinal(text)
                }
            } else {
                // Resultado parcial
                val partialJson = rec.partialResult
                val text = extractPartial(partialJson)
                if (text.isNotBlank()) {
                    onPartial(text)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "acceptWaveForm error", e)
        }
    }

    /** Fuerza el fin del segmento actual y obtiene el resultado. */
    fun flush() {
        if (!isReady || isClosed) return
        try {
            val text = extractText(recognizer?.finalResult ?: return)
            if (text.isNotBlank()) onFinal(text)
        } catch (e: Exception) {
            Log.w(TAG, "flush error", e)
        }
    }

    fun close() {
        isClosed = true
        isReady = false
        try {
            recognizer?.close()
        } catch (_: Exception) {}
        recognizer = null
        try {
            model?.close()
        } catch (_: Exception) {}
        model = null
    }

    fun isReady(): Boolean = isReady

    // ─────────────────── Descarga / descompresión del modelo ───────────────────

    private fun ensureModel(modelName: String): String? {
        val targetDir = File(modelsDir, modelName)
        // Comprobar si ya está descomprimido (existe am/ o conf/)
        if (targetDir.exists() && (File(targetDir, "am").exists() || File(targetDir, "conf").exists())) {
            return targetDir.absolutePath
        }

        onStatus("Descargando modelo ($modelName)… ~40 MB")
        val zipFile = File(modelsDir, "$modelName.zip")
        try {
            downloadFile("$MODEL_BASE_URL$modelName.zip", zipFile) { progress ->
                onStatus("Descargando modelo… $progress%")
            }
            onStatus("Descomprimiendo modelo…")
            unzip(zipFile, modelsDir)
            zipFile.delete()
            // A veces el zip crea una carpeta con el mismo nombre
            if (targetDir.exists()) return targetDir.absolutePath
            // Buscar carpeta recién creada
            modelsDir.listFiles()?.firstOrNull { it.isDirectory && it.name.contains(modelName.take(15)) }
                ?.let { return it.absolutePath }
            return targetDir.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error descargando modelo", e)
            onError("Error descargando modelo: ${e.message}")
            zipFile.delete()
            return null
        }
    }

    private fun downloadFile(urlStr: String, dest: File, onProgress: (Int) -> Unit) {
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 30_000
        conn.readTimeout = 60_000
        conn.connect()
        val total = conn.contentLengthLong
        conn.inputStream.use { input ->
            FileOutputStream(dest).use { output ->
                val buffer = ByteArray(8192)
                var downloaded = 0L
                var lastPct = -1
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    output.write(buffer, 0, read)
                    downloaded += read
                    if (total > 0) {
                        val pct = ((downloaded * 100) / total).toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            onProgress(pct)
                        }
                    }
                }
            }
        }
        conn.disconnect()
    }

    private fun unzip(zipFile: File, destDir: File) {
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(destDir, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos ->
                        zis.copyTo(fos)
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    private fun extractText(json: String): String {
        return try {
            JSONObject(json).optString("text", "").trim()
        } catch (_: Exception) {
            ""
        }
    }

    private fun extractPartial(json: String): String {
        return try {
            JSONObject(json).optString("partial", "").trim()
        } catch (_: Exception) {
            ""
        }
    }
}
