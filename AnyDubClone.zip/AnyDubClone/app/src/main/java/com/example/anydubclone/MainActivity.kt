package com.example.anydubclone

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.anydubclone.databinding.ActivityMainBinding
import com.example.anydubclone.service.OverlayService
import com.example.anydubclone.service.TranslationService
import com.example.anydubclone.util.DubSyncHelper
import com.example.anydubclone.util.TranslatorHelper
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * AnyDub Clone con captura de audio del sistema (MediaProjection + AudioPlaybackCapture).
 *
 * Dos modos:
 * 1. **Audio del sistema** (recomendado, estilo AnyDub real):
 *    - Pide permiso de captura de pantalla
 *    - Captura el audio que reproducen YouTube, Netflix, etc.
 *    - Muestra nivel de audio en tiempo real
 *    - Listo para conectar Whisper / Vosk / STT en la nube
 *
 * 2. **Micrófono** (fallback):
 *    - Usa SpeechRecognizer del sistema
 *    - Traduce y habla con TTS
 */
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var voiceEnabled = true
    private var useSystemAudio = true          // modo por defecto
    private var translatorHelper: TranslatorHelper? = null
    private lateinit var dubSync: DubSyncHelper

    // Receiver del nivel de audio del sistema
    private val audioLevelReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != TranslationService.BROADCAST_AUDIO_LEVEL) return
            val level = intent.getFloatExtra(TranslationService.EXTRA_LEVEL, 0f)
            val isSpeech = intent.getBooleanExtra(TranslationService.EXTRA_IS_SPEECH, false)

            binding.audioLevelBar.progress = (level * 100).toInt().coerceIn(0, 100)
            // No pisar el estado si hay texto de Vosk reciente
            if (!binding.tvStatus.text.contains("Traduc", ignoreCase = true) &&
                !binding.tvStatus.text.contains("Vosk", ignoreCase = true) &&
                !binding.tvStatus.text.contains("Reproduc", ignoreCase = true)
            ) {
                binding.tvStatus.text = if (isSpeech) {
                    "🎙 Voz detectada  (${(level * 100).toInt()}%)"
                } else {
                    "Escuchando sistema…  (${(level * 100).toInt()}%)"
                }
            }
        }
    }

    // Resultados de Vosk (STT)
    private val sttReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != TranslationService.BROADCAST_STT_RESULT) return
            val text = intent.getStringExtra(TranslationService.EXTRA_TEXT) ?: return
            val isFinal = intent.getBooleanExtra(TranslationService.EXTRA_IS_FINAL, false)

            if (text.isBlank()) return

            if (isFinal) {
                processRecognizedText(text)
            } else {
                // Parcial: mostrar en subtítulo
                binding.tvSubtitle.visibility = View.VISIBLE
                binding.tvSubtitle.text = text
                OverlayService.updateText(text, null)
            }
        }
    }

    // Estado de Vosk / descarga de modelo
    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != TranslationService.BROADCAST_STATUS) return
            val status = intent.getStringExtra(TranslationService.EXTRA_STATUS) ?: return
            binding.tvStatus.text = status
        }
    }

    // Permisos de micrófono (modo mic)
    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.RECORD_AUDIO] == true) {
            startMicTranslation()
        } else {
            Toast.makeText(this, getString(R.string.permission_required), Toast.LENGTH_LONG).show()
        }
    }

    // MediaProjection (captura de audio del sistema)
    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startSystemAudioService(result.resultCode, result.data!!)
        } else {
            Toast.makeText(
                this,
                "Se necesita permiso de captura de pantalla para el audio del sistema",
                Toast.LENGTH_LONG
            ).show()
            binding.tvStatus.text = "Permiso denegado"
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWebView()
        setupButtons()
        setupTts()
        translatorHelper = TranslatorHelper(this)

        // Registrar receivers
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Context.RECEIVER_NOT_EXPORTED
        } else 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(audioLevelReceiver, IntentFilter(TranslationService.BROADCAST_AUDIO_LEVEL), flags)
            registerReceiver(sttReceiver, IntentFilter(TranslationService.BROADCAST_STT_RESULT), flags)
            registerReceiver(statusReceiver, IntentFilter(TranslationService.BROADCAST_STATUS), flags)
        } else {
            registerReceiver(audioLevelReceiver, IntentFilter(TranslationService.BROADCAST_AUDIO_LEVEL))
            registerReceiver(sttReceiver, IntentFilter(TranslationService.BROADCAST_STT_RESULT))
            registerReceiver(statusReceiver, IntentFilter(TranslationService.BROADCAST_STATUS))
        }

        loadUrl("https://www.youtube.com")
    }

    private fun setupWebView() {
        val webView = binding.webView
        val settings = webView.settings

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.userAgentString = settings.userAgentString + " AnyDubClone/1.0"
        webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean = false

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                binding.etUrl.setText(url)
            }
        }
        webView.webChromeClient = WebChromeClient()
    }

    private fun setupButtons() {
        binding.btnGo.setOnClickListener { navigateFromEditText() }
        binding.btnBack.setOnClickListener {
            if (binding.webView.canGoBack()) binding.webView.goBack()
        }
        binding.btnForward.setOnClickListener {
            if (binding.webView.canGoForward()) binding.webView.goForward()
        }
        binding.btnReload.setOnClickListener { binding.webView.reload() }

        binding.etUrl.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                navigateFromEditText()
                true
            } else false
        }

        // Selector de modo
        binding.btnModeSystem.setOnClickListener {
            useSystemAudio = true
            updateModeButtons()
            Toast.makeText(this, "Modo: Audio del sistema (YouTube, Netflix…)", Toast.LENGTH_SHORT).show()
        }
        binding.btnModeMic.setOnClickListener {
            useSystemAudio = false
            updateModeButtons()
            Toast.makeText(this, "Modo: Micrófono", Toast.LENGTH_SHORT).show()
        }
        updateModeButtons()

        binding.btnLiveTranslate.setOnClickListener {
            if (isListening) {
                stopLiveTranslation()
            } else {
                if (useSystemAudio) {
                    requestSystemAudioCapture()
                } else {
                    checkMicPermissionAndStart()
                }
            }
        }

        binding.btnToggleVoice.setOnClickListener {
            voiceEnabled = !voiceEnabled
            dubSync.enabled = voiceEnabled
            if (!voiceEnabled) dubSync.stop()
            binding.btnToggleVoice.text = if (voiceEnabled) "Voz ON" else "Voz OFF"
            Toast.makeText(
                this,
                if (voiceEnabled) "Doblaje con voz + ducking activado" else "Solo subtítulos",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun updateModeButtons() {
        if (useSystemAudio) {
            binding.btnModeSystem.alpha = 1f
            binding.btnModeMic.alpha = 0.45f
            binding.audioLevelBar.visibility = View.VISIBLE
        } else {
            binding.btnModeSystem.alpha = 0.45f
            binding.btnModeMic.alpha = 1f
            binding.audioLevelBar.visibility = View.GONE
        }
    }

    private fun navigateFromEditText() {
        var url = binding.etUrl.text.toString().trim()
        if (url.isEmpty()) return
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://$url"
        }
        loadUrl(url)
    }

    private fun loadUrl(url: String) {
        binding.webView.loadUrl(url)
        binding.etUrl.setText(url)
    }

    private fun setupTts() {
        dubSync = DubSyncHelper(
            context = this,
            onSpeakingChanged = { speaking ->
                if (speaking) {
                    binding.tvStatus.text = getString(R.string.speaking)
                } else if (isListening) {
                    binding.tvStatus.text = "Escuchando sistema…"
                }
            },
            onQueueSizeChanged = { size ->
                if (size > 0 && isListening) {
                    // Opcional: mostrar tamaño de cola
                }
            }
        )
        dubSync.initTts(this)
    }

    override fun onInit(status: Int) {
        dubSync.onTtsReady(status)
        dubSync.enabled = voiceEnabled
    }

    // ───────────────────────── Modo Sistema ─────────────────────────

    private fun requestSystemAudioCapture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            Toast.makeText(
                this,
                "La captura de audio del sistema requiere Android 10 o superior",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        // Pedir también permiso de overlay si no está
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission), Toast.LENGTH_LONG).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }

        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun startSystemAudioService(resultCode: Int, data: Intent) {
        isListening = true
        binding.btnLiveTranslate.text = getString(R.string.stop_translation)
        binding.tvStatus.text = "Iniciando captura de audio del sistema…"
        binding.tvSubtitle.visibility = View.VISIBLE
        binding.tvSubtitle.text = "Reproduce un video. Vosk reconocerá el audio y lo traducirá."
        binding.audioLevelBar.visibility = View.VISIBLE
        binding.audioLevelBar.progress = 0

        // Overlay de subtítulos
        startService(Intent(this, OverlayService::class.java))

        // Servicio de captura + Vosk (modelo inglés por defecto para videos)
        val serviceIntent = Intent(this, TranslationService::class.java).apply {
            action = TranslationService.ACTION_START
            putExtra(TranslationService.EXTRA_RESULT_CODE, resultCode)
            putExtra(TranslationService.EXTRA_RESULT_DATA, data)
            putExtra(TranslationService.EXTRA_MODE, "system")
            putExtra(TranslationService.EXTRA_MODEL, "en") // en | es
        }
        ContextCompat.startForegroundService(this, serviceIntent)

        Toast.makeText(
            this,
            "Captura iniciada. Reproduce un video en YouTube u otra app.",
            Toast.LENGTH_LONG
        ).show()
    }

    // ───────────────────────── Modo Micrófono ─────────────────────────

    private fun checkMicPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestMicPermission.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        } else {
            startMicTranslation()
        }
    }

    private fun startMicTranslation() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Reconocimiento de voz no disponible", Toast.LENGTH_LONG).show()
            return
        }

        isListening = true
        binding.btnLiveTranslate.text = getString(R.string.stop_translation)
        binding.tvStatus.text = getString(R.string.listening)
        binding.tvSubtitle.visibility = View.VISIBLE

        startService(Intent(this, OverlayService::class.java))

        // Servicio solo como notificación (sin MediaProjection)
        val serviceIntent = Intent(this, TranslationService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)

        startSpeechRecognition()
    }

    private fun startSpeechRecognition() {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                binding.tvStatus.text = getString(R.string.listening)
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                if (isListening) binding.tvStatus.text = "Reiniciando escucha…"
            }

            override fun onError(error: Int) {
                if (!isListening) return
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                    SpeechRecognizer.ERROR_CLIENT -> restartRecognitionWithDelay()
                    else -> {
                        binding.tvStatus.text = "Error ($error). Reintentando…"
                        restartRecognitionWithDelay()
                    }
                }
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!text.isNullOrBlank()) processRecognizedText(text)
                if (isListening) restartRecognitionWithDelay()
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!partial.isNullOrBlank()) {
                    binding.tvSubtitle.text = partial
                    OverlayService.updateText(partial, null)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            binding.tvStatus.text = "Error al iniciar reconocimiento"
        }
    }

    private fun restartRecognitionWithDelay() {
        binding.root.postDelayed({
            if (isListening && !useSystemAudio) startSpeechRecognition()
        }, 400)
    }

    private fun processRecognizedText(original: String) {
        binding.tvStatus.text = getString(R.string.translating)
        binding.tvSubtitle.visibility = View.VISIBLE
        binding.tvSubtitle.text = original

        lifecycleScope.launch {
            try {
                val translated = translatorHelper?.translateToSpanish(original) ?: original
                binding.tvSubtitle.text = translated
                OverlayService.updateText(original, translated)

                if (voiceEnabled && translated.isNotBlank()) {
                    // Encola con debounce + ducking del audio original
                    dubSync.enqueue(translated)
                } else if (isListening) {
                    binding.tvStatus.text = if (useSystemAudio) "Escuchando sistema…" else getString(R.string.listening)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                binding.tvStatus.text = "Error de traducción"
            }
        }
    }

    // ───────────────────────── Detener ─────────────────────────

    private fun stopLiveTranslation() {
        isListening = false

        speechRecognizer?.stopListening()
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
        if (::dubSync.isInitialized) dubSync.stop()

        // Detener captura de sistema
        val stopIntent = Intent(this, TranslationService::class.java).apply {
            action = TranslationService.ACTION_STOP
        }
        startService(stopIntent)
        stopService(Intent(this, TranslationService::class.java))
        stopService(Intent(this, OverlayService::class.java))

        binding.btnLiveTranslate.text = getString(R.string.start_live)
        binding.tvStatus.text = "Listo"
        binding.tvSubtitle.visibility = View.GONE
        binding.tvSubtitle.text = ""
        binding.audioLevelBar.progress = 0
    }

    override fun onDestroy() {
        try { unregisterReceiver(audioLevelReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(sttReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(statusReceiver) } catch (_: Exception) {}
        stopLiveTranslation()
        if (::dubSync.isInitialized) dubSync.shutdown()
        translatorHelper?.close()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }
}
