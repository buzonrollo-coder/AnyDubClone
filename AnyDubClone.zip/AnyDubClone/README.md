# AnyDub Clone – Traductor de video en vivo para Android

Clon educativo inspirado en **AnyDub: Video & PDF Translator** (PascualLabs).

## ¿Qué hace?

- Navegador WebView optimizado para sitios de video (YouTube, TikTok, Twitch, etc.)
- **Traducción en vivo del audio hablado** a español:
  1. Captura de voz (micrófono)
  2. Speech-to-Text (Android SpeechRecognizer – análogo a Whisper)
  3. Traducción (ML Kit Translate on-device)
  4. Text-to-Speech en español
  5. Overlay flotante de subtítulos (original + traducción)

## Arquitectura (inspirada en AnyDub)

```
┌──────────────────────────────────────┐
│  MediaProjection (permiso usuario)   │
└──────────────────┬───────────────────┘
                   ▼
┌──────────────────────────────────────┐
│  AudioPlaybackCaptureConfiguration   │  ← USAGE_MEDIA / GAME
└──────────────────┬───────────────────┘
                   ▼
┌──────────────────────────────────────┐
│  AudioRecord (PCM 16 kHz mono)       │  ← hilo de captura
└──────────────────┬───────────────────┘
                   ▼
┌──────────────────────────────────────┐
│  Nivel RMS + buffer circular         │  ← listo para STT
└──────────────────┬───────────────────┘
                   ▼
┌─────────────┐  ┌──────────────┐  ┌─────────────┐
│ Whisper/    │→ │ Traducción   │→ │ TTS +       │
│ Vosk / API  │  │ (ML Kit)     │  │ Overlay     │
└─────────────┘  └──────────────┘  └─────────────┘
```

### Cómo se captura el audio del sistema

1. El usuario pulsa **“Audio del sistema”** y luego **“Iniciar traducción”**.
2. Android muestra el diálogo nativo de **captura de pantalla**.
3. Si acepta, se obtiene un `MediaProjection`.
4. Con él se construye un `AudioPlaybackCaptureConfiguration` que escucha `USAGE_MEDIA`.
5. Se crea un `AudioRecord` con esa configuración y se lee PCM en un hilo dedicado.
6. El nivel de audio se envía por broadcast a la UI (barra de progreso).
7. Los buffers quedan disponibles para conectar Whisper, Vosk o una API de STT.

## Diferencias con AnyDub real

| Característica              | AnyDub real                          | Este clon                          |
|----------------------------|--------------------------------------|------------------------------------|
| Captura de audio           | System audio (MediaProjection)       | Micrófono                          |
| ASR                        | Whisper on-device (~99 idiomas)      | SpeechRecognizer del sistema       |
| Traducción                 | Microsoft / Google / AnyDub AI       | ML Kit (Google) on-device           |
| TTS                        | Voces neurales de alta calidad       | TextToSpeech del sistema           |
| Documentos / OCR           | Sí (PDF, EPUB, OCR de subtítulos)    | No implementado                    |
| Captura de pantalla        | Sí                                   | No                                 |

## Cómo compilar

1. Abre la carpeta `AnyDubClone` en **Android Studio** (Hedgehog o más reciente).
2. Espera a que Gradle sincronice.
3. Conecta un dispositivo o emulador (Android 8.0+ / API 26+).
4. Ejecuta la app.

### Permisos necesarios

- **Micrófono** → para capturar el audio hablado
- **Mostrar sobre otras apps** → para el overlay de subtítulos

La primera vez que uses la traducción, ML Kit descargará el modelo de inglés→español (requiere Wi-Fi o datos).

## Mejoras posibles (próximos pasos)

1. **Captura de audio del sistema** con `MediaProjection` + `AudioPlaybackCapture` (Android 10+).
2. Integrar **whisper.cpp** o un modelo Whisper cuantizado vía ONNX Runtime / TFLite.
3. Detección automática de idioma fuente.
4. Cola de segmentos de audio para menor latencia y mejor sincronización.
5. Mezcla de volumen (bajar audio original mientras habla el doblaje).
6. Lector de documentos + OCR de subtítulos quemados.
7. Modo “solo subtítulos” / “solo voz” más refinado.

## Licencia

Código de ejemplo educativo. AnyDub es marca y producto de PascualLabs.
No está afiliado ni respaldado por ellos.

## Vosk STT (integrado)

- Biblioteca: `com.alphacephei:vosk-android:0.3.75`
- Modelo por defecto: **vosk-model-small-en-us-0.15** (~40 MB)
  - Se descarga automáticamente la primera vez que usas "Audio del sistema"
  - Guardado en `filesDir/vosk-models/`
- Flujo:
  1. Audio del sistema (PCM 16 kHz) → Vosk
  2. Texto reconocido (parcial + final) → broadcast
  3. MainActivity traduce con ML Kit → español
  4. TTS habla la traducción + overlay

### Cambiar a modelo español

En `MainActivity.startSystemAudioService`, cambia:
```kotlin
putExtra(TranslationService.EXTRA_MODEL, "es")
```

### Requisitos

- Android 10+ para captura de sistema
- Primera ejecución: Wi-Fi recomendado (descarga ~40 MB)
- Dispositivo real preferible (el emulador puede no capturar audio de apps)

## Sincronización del doblaje (DubSyncHelper)

- **Audio focus MAY_DUCK**: al hablar, Android hace que YouTube/Netflix bajen el volumen solos.
- **Cola de frases** (máx. 4): evita cortar frases y acumular demasiado retraso.
- **Debounce 180 ms**: espera a que Vosk cierre el segmento antes de encolar.
- **Speech rate 1.05**: ligeramente más rápido para no ir a la zaga.
- **Liberación de foco**: al vaciar la cola, el audio original recupera volumen.

Ajustables en `DubSyncHelper`:
- `DEBOUNCE_MS`, `MAX_QUEUE`, `speechRate`, `pitch`
